(() => {
  'use strict';
  const html = document.documentElement;
  const language = html.lang === 'fr' ? 'fr' : 'en';
  const page = /^(index|privacy|terms|support|about)$/.test(html.dataset.page) ? html.dataset.page : 'index';
  const header = document.querySelector('header');
  if (!header) return;
  const label = document.createElement('label');
  label.className = 'lang-select';
  const select = document.createElement('select');
  select.setAttribute('aria-label', language === 'fr' ? 'Langue' : 'Language');
  for (const [value, title] of [['en', 'English'], ['fr', 'Français']]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = title;
    select.append(option);
  }
  select.value = language;
  // Remember the homepage preference; explicit legal/support URLs remain authoritative.
  if (page === 'index' && language === 'en') {
    try {
      if (localStorage.getItem('eluvaLang') === 'fr') {
        const preferred = new URL('fr/index.html', new URL(html.dataset.siteRoot || './', document.baseURI));
        preferred.hash = location.hash;
        location.replace(preferred.href);
        return;
      }
    } catch (_) { /* A blocked preference must not prevent access. */ }
  }
  try { localStorage.setItem('eluvaLang', language); } catch (_) { /* Storage may be disabled. */ }
  select.addEventListener('change', () => {
    const nextLanguage = select.value === 'fr' ? 'fr' : 'en';
    const root = new URL(html.dataset.siteRoot || './', document.baseURI);
    const destination = new URL((nextLanguage === 'fr' ? 'fr/' : '') + page + '.html', root);
    destination.hash = location.hash;
    try { localStorage.setItem('eluvaLang', nextLanguage); } catch (_) { /* Navigation still works. */ }
    location.assign(destination.href);
  });
  label.append(select);
  header.append(label);
})();
