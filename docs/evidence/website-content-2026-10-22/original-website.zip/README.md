# Eluva static website handoff

## Delivery

`public/` is the deployment directory. Upload the **contents** of `public/` to a standard static web host; no Node.js installation, package install, build step, database, or server-side route is required.

This handoff preserves the current Eluva layout, colours, copy, screenshots, CSS motion, anchor navigation, and English/German language selector. It is a static site: all motion continues to run in the browser after deployment.

## Structure

```text
website-handoff/
├── public/
│   ├── index.html              # Marketing homepage
│   ├── support.html            # Technical support
│   ├── privacy.html            # Privacy policy draft
│   ├── terms.html              # Terms of Use draft
│   ├── about.html              # Existing About page retained for navigation
│   └── assets/
│       ├── css/style.css       # Shared layout, responsive sizing, and CSS motion
│       ├── js/main.js          # Language selector and locale-specific screenshot swap
│       ├── images/             # Logo and English/German product screenshots
│       ├── videos/             # Empty: no videos are used by the current site
│       └── animations/         # Empty: animation is CSS-based, with no external data asset
├── README.md
└── URLS.txt
```

## Deployment and local preview

1. Upload the contents of `public/` to the web root of any static host.
2. Preserve the `assets/` directory structure and case-sensitive filenames.
3. Open `index.html` from the deployed domain.

For local preview from the `website-handoff/` directory, run:

```sh
python3 -m http.server 8080 --directory public
```

Then visit `http://localhost:8080/index.html`. This command is only a local preview server; it is not required for deployment.

## Content update locations

- Homepage and existing product copy: `public/index.html`
- Support content: `public/support.html`
- Privacy policy content: `public/privacy.html`
- Terms content: `public/terms.html`
- Shared visual styling and CSS animation: `public/assets/css/style.css`
- Language selector and German screenshot switching: `public/assets/js/main.js`
- Images: `public/assets/images/`

## Motion and interaction inventory

| Original behaviour | File | Verification result |
| --- | --- | --- |
| Smooth in-page anchor navigation | `assets/css/style.css` | HTTP page check completed; visual interaction not browser-verified in this handoff pass |
| Hero phone float | `assets/css/style.css` (`phone-float`) | Code and CSS reference checked; visual playback not browser-verified |
| Chat phone float | `assets/css/style.css` (`chat-float`) | Code and CSS reference checked; visual playback not browser-verified |
| Decorative orb breathing | `assets/css/style.css` (`orb-breathe`) | Code and CSS reference checked; visual playback not browser-verified |
| Echo ripple loop | `assets/css/style.css` (`ripple-pulse`) | Code and CSS reference checked; visual playback not browser-verified |
| Star glow loop | `assets/css/style.css` (`star-glow`) | Code and CSS reference checked; visual playback not browser-verified |
| English/German selector and screenshot swap | `assets/js/main.js`, `assets/images/*-de.png` | JavaScript syntax checked; browser interaction not visually verified |
| Reduced-motion preference support | `assets/css/style.css` (`prefers-reduced-motion`) | Code reference checked; OS preference behaviour not verified |

The current site does not include video, GIF, Lottie, Canvas, carousel, or third-party animation-player assets.

## Resource and size optimisation

- No Base64 or data-URL image/video/animation resources were found in the original HTML.
- Shared CSS and JavaScript are now single reusable files. Images are external files under `assets/images/` and are not duplicated in HTML.
- Only rendered English/German screenshots and the supplied logo were copied. Deployment archives, Git metadata, build caches, and unused historical assets are excluded.
- Screenshot assets retain their original PNG format because they contain UI text; no lossy recompression was applied.
- The shared stylesheet imports the existing Google Fonts URL. If fully offline typography is required, obtain the applicable font licences/files and replace the `@import` with local font files; this was not done because no local font files were supplied.

Measured before/after values:

| Measure | Actual result |
| --- | ---: |
| Original rendered-page HTML total (`index`, `contact`, `privacy`, `about`) | 9,242 bytes |
| Final HTML total (`index`, `support`, `privacy`, `terms`, retained `about`) | 11,461 bytes |
| Final deployment directory (`public/`) | 14,808 KiB |
| Final ZIP | 15,068,790 bytes (14,716 KiB) |

The final HTML total is larger because `terms.html` is an additional required standalone document and the support/privacy pages include explicit launch-status notices. It does not contain embedded image data.

Largest deployed resources:

| Resource | Size |
| --- | ---: |
| `assets/images/home-de.png` | 2,524 KiB |
| `assets/images/home.png` | 2,520 KiB |
| `assets/images/not-lit.png` | 1,964 KiB |
| `assets/images/not-lit-de.png` | 1,964 KiB |
| `assets/images/lit-up-de.png` | 1,956 KiB |
| `assets/images/lit-up.png` | 1,952 KiB |
| `assets/images/eluva-logo.png` | 684 KiB |

## Checks performed

- Local HTTP preview started with Python's static server.
- Direct HTTP access returned `200` for `index.html`, `support.html`, `privacy.html`, and `terms.html`.
- Direct HTTP access returned `200` for the shared CSS, shared JavaScript, logo, and checked English/German screenshot resources.
- `assets/js/main.js` passed `node --check` syntax validation.
- File references were scanned for `file:`, `blob:`, `data:image`, and local absolute `/Users/` paths; no matches were found in `public/`.
- Browser visual regression testing, animated playback observation, responsive-device testing, and App Store review were not performed in this handoff pass; they are not claimed as passed.

## Required before public launch / App Store submission

The following are **not final** and must be supplied, approved, and inserted before a public launch or submission:

1. Complete approved Privacy Policy, including company/controller identity, effective date, data categories, purposes, legal bases, retention, sharing/third-party SDKs, international transfers, children policy, security, rights, and account deletion process.
2. Complete approved Terms of Use, including acceptable use, user content, moderation, termination, liability, governing law, and dispute terms.
3. Confirmed technical-support email address or support URL. The current support page intentionally does not invent one.
4. Confirmed privacy contact address.
5. Real App Store / download URL. The visible download button intentionally does not link to an unprovided store page.
6. Final company/legal entity name, registered address, jurisdiction, and effective dates.
7. Final confirmation that the Google Fonts import may be used in the target deployment, or licensed local font files.

